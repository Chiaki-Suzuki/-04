let app = new Vue({
  el: "#app",
  data: {
    column: [{ name: "", price: "", num: "" }],
    items: [{ name: "", price: "" }]
  },
  methods: {
    addColumn: function () {
      // 商品入力欄を追加
      let newItems = { name: null, price: null, num: null };
      this.column.push(newItems);

      // 合計金額表示欄を追加
      let newSum = { name: null };
      this.items.push(newSum);

      // 商品情報を合計金額表示欄に表示
      for (i = 0; i < this.column.length; i++) {
        this.column[i].name = this.items[i].name;
      }
    },
    // 商品ごとの合計
    itemSumPrice: function () {
      for (i = 0; i < this.column.length; i++) {
        this.items[i].price = this.column[i].price * this.column[i].num;
      }
    }
  },
  computed: {
    // 全ての合計
    totalSumPrice: function () {
      let sum = 0;
      for (i = 0; i < document.querySelectorAll(".msg").length; i++) {
        sum += this.items[i].price;
      }
      return sum;
    }
  }
});
